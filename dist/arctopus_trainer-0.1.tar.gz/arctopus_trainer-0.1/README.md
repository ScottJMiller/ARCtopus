## The ARCtopus
This is the repository for all code related to my entry in the 2025 ARC Prize competition. More to come. 
